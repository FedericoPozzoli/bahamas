"""Module for generating power spectral density (PSD) models for gravitational wave signals.
This module includes various signal models, noise models, and functions to compute the total PSD
from multiple sources. It also provides functions for generating Gaussian processes and averaging data.
The module uses JAX for efficient computation and supports both time and frequency domain analysis.
"""
from bahamas.model import average_envelope as env
from bahamas.model import average_envelope_mixture as env2
from bahamas.model import egp


from scipy.signal import welch
import jax
import jax.numpy as jnp
from jax.scipy.special import gammaln
from jax import random, lax
from astropy.cosmology import Planck18
import warnings
import numpy as np


# Enable 64-bit precision in JAX
jax.config.update('jax_enable_x64', True)

# Suppress warnings
warnings.filterwarnings('ignore')

# Constants
Planck18_H0 = Planck18.H0.si.value
H02 = Planck18_H0**2
clight = 299792458.0  # Speed of light in m/s
L = 8.3  # Arm length of LISA in seconds
year = 31557600.0  # Seconds in a year

##################################################################################
#SIGNAL MODELS
##################################################################################

@jax.jit
def broken_power_law(freqs, par, posterior=False):
    """
    Broken power law model for gravitational wave signal.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """
    if posterior:
        amp = par[0]
        break_freq = par[1]
        slope1 = par[2]
        slope2 = par[3]
        
    else:
        amp = par['amp']
        slope1 = par['slope1']
        slope2 = par['slope2']
        break_freq = par['break_freq']


    Omega = jnp.where(freqs < 10**break_freq,
                      10**amp * (freqs / 10**break_freq)**slope1,
                      10**amp * (freqs / 10**break_freq)**(slope2))

    S_h = Omega * (3 * H02) / (4 * jnp.pi**2 * freqs**3)

    return S_h


@jax.jit
def power_law(freqs, par, posterior = False):
    """
    Power law model for gravitational wave signal.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """
    if posterior:
        amp = par[0]
        slope = par[1]
    
    else:
        amp = par['amp']
        slope = par['slope']

    f0 = 1 #10**-3
    Omega = 10**amp*(freqs/ f0)**slope
    S_h = Omega * (3*H02)/ (4*jnp.pi**2*freqs**3)

    return S_h

@jax.jit
def Omega_vacuum(freqs, par, posterior = False):
    """"
    Vacuum model for gravitational wave signal.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """
    if posterior:
        Avac = par[0]
        slope = par[1]
    
    else:
        Avac = par['Avac']
        slope = par['slope']

    f0 = 1 #10**-3
    Omega = 10**Avac*(freqs/ f0)**slope
    S_h = Omega * (3*H02)/ (4*jnp.pi**2*freqs**3)

    return S_h

@jax.jit
def Omega_Edd(freqs, par, posterior = False):
    """
    Eddington accretion model for gravitational wave signal.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """
    #Am = 2.33e-06
    #A_vac_from_GR = 4.97e-11
    if posterior:
        Avac = par[0]
        fedd = par[1]
    
    else:
        #Am = par['Am']
        Avac= par['Avac']
        fedd = par['fedd']

    coef = -11.611197718018854 
    Omega =  10**Avac * freqs**(2./3) / (1 + (10**coef)*freqs**(-8./3)*10**fedd) 

    S_h = Omega * (3*H02) / (4*jnp.pi**2*freqs**3)

    return S_h

@jax.jit
def Omega_DF(freqs, par, posterior = False):

    #A_vaS_h = -10.303706386648098,
    A_m = -6.564594467605877

    if posterior:
        Avac = par[0]
        rho = par[1]
    
    else:
        #Am = par['Am']
        Avac = par['Avac']
        rho = par['rho']

    rho = 10**rho * 10**-7
    numerator = 10**Avac * freqs**(2./3)
    denominator = (1 - rho * 10** A_m * freqs**(-11./3)*jnp.log(freqs))

    S_h = numerator * (3*H02) / (4*jnp.pi**2*freqs**3) / denominator
    return S_h

@jax.jit
def Omega_DF_bump(freqs, par, posterior = False):
    """
    Dynamical friction model for gravitational wave signal with a bump.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """
    A_m = -13.564594467605877

    if posterior:
        Avac = par[0]
        rho = par[1]
    
    else:
        #Am = par['Am']
        Avac = par['Avac']
        rho = par['rho']

    numerator = 10**Avac * freqs**(2./3)
    denominator = (1 - 10**rho * 10**A_m * freqs**(-11./3)*jnp.log(freqs)) 
    log_f_peak = -3.4059 + 0.2623 * rho 
    amplitude = 1.2034 + (-0.0262 * rho)
    sigma = 0.2217
    Gauss = amplitude * jnp.exp(-((jnp.log10(freqs) - log_f_peak)**2) / (2 * sigma**2))
    Gauss_correction = 1 + Gauss
    omega =  numerator / denominator / Gauss_correction

    S_h = omega * (3*H02) / (4*jnp.pi**2*freqs**3) 
    return S_h

@jax.jit
def Omega_fraction(freqs, par, posterior = False):
    """
    Fractional model for gravitational wave signal.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """
    A_m = -13.564594467605877

    if posterior:
        fraction = par[1]
        
    else:
        
        fraction  = par['fraction']
        

    S_h = fraction * Omega_DF_bump(freqs, par) + (1 - fraction) * Omega_vacuum(freqs, par)

    return S_h

   
@jax.jit
def extra_foreground(freqs, par, posterior = False):    
    """
    Extra foreground model for gravitational wave signal.
    https://arxiv.org/abs/2407.10642
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """

    if posterior:
        a = par[0]
        b = par[1]
    
    else:
        a = par['a']
        b = par['b']
	
    gamma1 = 0.741
    f_b = 7.2e-3
    gamma2 = -0.255
    gamma3 = 3 

    Omega =  10**a*(freqs/f_b)**gamma1 * (1 + (freqs/f_b)**4.15)**gamma2 * jnp.exp(-10**b*freqs**gamma3)
    S_h = Omega* (3*H02) / (4*jnp.pi**2*freqs**3)
	
    return S_h

@jax.jit
def galactic_foreground(freqs, par, posterior = False, injected = False):
    """
    Galactic foreground model for gravitational wave signal.
    https://arxiv.org/abs/2103.14598
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
        injected (bool): If True, uses injected parameters.
    Returns:
        array: Power spectral density.
    """     

    if posterior:
        alpha, amp, fknee, fr1, fr2, lat, \
            long, psi, s1, s2 = par[0], par[1], par[2], par[3], par[4], par[5], par[6], par[7], par[8], par[9]
        
    if 'fknee' not in par:
        Tobs = par['Tobs'] / year
        
        
        alpha = par['alpha']
        amp = par['amp']
        a1 = par['a1']
        b1 = par['b1']
        ak = par['ak']
        bk = par['bk']
        fr2 = par['fr2']
        
        fr1 = a1 * jnp.log10(Tobs) + b1
        fknee = ak * jnp.log10(Tobs) + bk
    else:
        alpha = par['alpha']
        amp = par['amp']
        fknee = par['fknee']
        fr1 = par['fr1']
        fr2 = par['fr2']
        
    
    res = 10**amp*jnp.exp(-(freqs/10**fr1)**alpha) *\
        (freqs**(-7./3.))*0.5*(1.0 + jnp.tanh(-(freqs-10**fknee)/10**fr2))
    
    fstar = 1 / L
    x = 2*jnp.pi * (freqs / fstar) * jnp.sin(2*jnp.pi * (freqs / fstar))
    response = 4 * x**2 
    psd = res*response
    return psd


@jax.jit
def galactic_foreground_time(freqs, par, posterior=False, injected=False, t1=0, t2=0, tdi=0):
    """
    Galactic foreground model for gravitational wave signal with time dependence.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
        injected (bool): If True, uses injected parameters.
        t1 (float): Start time for the envelope.
        t2 (float): End time for the envelope.
        tdi (int): TDI channel (0 = A, 1 = E).
    Returns:
        array: Power spectral density.
    """
    
    if posterior:
        alpha, amp, fknee, fr1, fr2, lat, \
            long, psi, s1, s2 = par[0], par[1], par[2], par[3], par[4], par[5], par[6], par[7], par[8], par[9]
        
    if 'fknee' not in par:
        Tobs = par['Tobs'] / year
        
        alpha = par['alpha']
        amp = par['amp']
        a1 = par['a1']
        b1 = par['b1']
        ak = par['ak']
        bk = par['bk']
        fr2 = par['fr2']
        lat = par['lat']
        long = par['long']
        psi = par['psi']
        s1 = par['s1']
        s2 = par['s2']
        
        fr1 = a1 * jnp.log10(Tobs) + b1
        fknee = ak * jnp.log10(Tobs) + bk
    else:
        alpha = par['alpha']
        amp = par['amp']
        fknee = par['fknee']
        fr1 = par['fr1']
        fr2 = par['fr2']
        lat = par['lat']
        long = par['long']
        psi = par['psi']
        s1 = par['s1']
        s2 = par['s2']

    amp_time = env.envelopes_gaussian(
        lat, long, s1, s2, psi, t1, t2, 
        LISA_Orbital_Freq=1 / year, alpha0=0., beta0=0., tdi=tdi
    )

    res = (
        amp_time * 10**amp * jnp.exp(-(freqs / 10**fr1)**alpha) *
        (freqs**(-7./3.)) * 0.5 * (1.0 + jnp.tanh(-(freqs - 10**fknee) / 10**fr2))
    )

    fstar = 1 / L
    x = 2 * jnp.pi * (freqs / fstar) * jnp.sin(2 * jnp.pi * (freqs / fstar))
    
    psd = res * x**2
    return psd


##################################################################################Galaxy Prototype
@jax.jit
def galactic_prototype(freqs, par, posterior=False, injected=False, t1=0, t2=0, tdi=0):
    """
    Galactic foreground model for gravitational wave signal with time dependence.
    The average time envelope is computed using mixture of gaussian in the sky.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
        injected (bool): If True, uses injected parameters.
        t1 (float): Start time for the envelope.
        t2 (float): End time for the envelope.
        tdi (int): TDI channel (0 = A, 1 = E).
    Returns:
        array: Power spectral density.
    """

    if posterior:
        alpha, amp, fknee, fr1, fr2, lat, \
            long, psi, s1, s2 = par[0], par[1], par[2], par[3], par[4], par[5], par[6], par[7], par[8], par[9]
        
    if 'fknee' not in par:
        Tobs = par['Tobs'] / year 
        
        alpha = par['alpha']
        amp = par['amp']
        a1 = par['a1']
        b1 = par['b1']
        ak = par['ak']
        bk = par['bk']
        fr2 = par['fr2']
        lat = par['lat']
        long = par['long']
        psi = par['psi']
        w = par['w']
        sX = par['sX']
        sY = par['sY']
        
        fr1 = a1 * jnp.log10(Tobs) + b1
        fknee = ak * jnp.log10(Tobs) + bk
    else:
        alpha = par['alpha']
        amp = par['amp']
        fknee = par['fknee']
        fr1 = par['fr1']
        fr2 = par['fr2']
        lat = par['lat']
        long = par['long']
        psi = par['psi']
        w = par['w']
        sX = par['sX']
        sY = par['sY']

    amp_time = env2.envelopes_gaussian(
    lat, long, sX, sY, w, psi, t1, t2, 
    LISA_Orbital_Freq=1 / year, alpha0=0., beta0=0., tdi=tdi
    )

    res = (
        amp_time * 10**amp * jnp.exp(-(freqs / 10**fr1)**alpha) *
        (freqs**(-7./3.)) * 0.5 * (1.0 + jnp.tanh(-(freqs - 10**fknee) / 10**fr2))
    )

    fstar = 1 / L
    x = 2 * jnp.pi * (freqs / fstar) * jnp.sin(2 * jnp.pi * (freqs / fstar))
    
    psd = res * x**2
    return psd


##################################################################################NOISE
@jax.jit
def Stm(f, A):
    """
    Test mass noise model. True value of A is 3.
    Args:
        f (array): Frequency array.
        A (float): Amplitude parameter.
    Returns:
        array: Power spectral density.
    """
    
    return A**2*10**(-30)*(1 + (0.4*10**-3/f)**2)*(1 + (f/(8*10**-3))**4)*(1/(2*jnp.pi*f*clight)**2) 

@jax.jit
def Soms(f, P):
    """
    Optical metrology noise model. True value of P is 15.
    Args:
        f (array): Frequency array.
        P (float): Amplitude parameter.
    Returns:
        array: Power spectral density.
    """
 
    return P**2*10**(-24)*(1 + (2*10**-3/f)**4)*(2*jnp.pi*f/clight)**2

@jax.jit
def noise(freqs, par, posterior = False):
    """
    Instrumental noise model in AE channel.
    Args:
        freqs (array): Frequency array.
        par (dict or array): Parameters for the model.
        posterior (bool): If True, uses a different parameterization.
    Returns:
        array: Power spectral density.
    """
    if posterior:
        A = par[0]
        P = par[1]
    
    else:
        A = par['A']
        P = par['P']

    psd  = 8*jnp.sin(2*jnp.pi*freqs*L)**2*(Soms(freqs, P)*(jnp.cos(2*jnp.pi*freqs*L) + 2) 
                                          + 2*(3 + 2*jnp.cos(2*jnp.pi*freqs*L) + jnp.cos(4*jnp.pi*freqs*L))*Stm(freqs, A))
    
    return psd


##################################################################################

def model_psd(freqs, sources, response, injected=False, tdi=0, **kwargs):
    """
    Computes the total power spectral density (PSD) by combining multiple sources.

    Args:
        freqs (array): Frequency array.
        sources (dict): Dictionary of sources with their parameters.
        response (float): Response factor to scale the PSD.
        injected (bool, optional): If True, uses injected parameters for sources. Defaults to False.
        tdi (int, optional): Time-delay interferometry channel (0 = A, 1 = E). Defaults to 0.
        **kwargs: Additional arguments for specific sources (e.g., `matrix_egp`, `t1`, `t2`).

    Returns:
        array: Total PSD if `injected` is False.
        tuple: Total PSD and list of true PSDs for each source if `injected` is True.
    """
    if injected:
        # Convert injected parameters into a dictionary format
        dict1 = {}
        for source_name, param_list in sources.items():
            source = {param["name"]: param["injected"] for param in param_list}
            dict1[source_name] = source
        sources = dict1

    # Initialize PSD arrays
    psd = jnp.zeros(len(freqs))
    true_psd = []

    # Loop through each source and compute its contribution to the PSD
    for source_name in sources.keys():
        if source_name == 'broken_power_law':
            psd += response * broken_power_law(freqs, sources[source_name])
            if injected:
                true_psd.append(response * broken_power_law(freqs, sources[source_name]))

        elif source_name == 'dynamical_friction':
            psd += response * Omega_DF_bump(freqs, sources[source_name])
            if injected:
                true_psd.append(response * Omega_DF_bump(freqs, sources[source_name]))

        elif source_name == 'eddington_accretion':
            psd += response * Omega_Edd(freqs, sources[source_name])
            if injected:
                true_psd.append(response * Omega_Edd(freqs, sources[source_name]))

        elif source_name == 'power_law':
            psd += response * power_law(freqs, sources[source_name])
            if injected:
                true_psd.append(response * power_law(freqs, sources[source_name]))

        elif source_name == 'egp':
            matrix = kwargs.get('matrix_egp')
            psd += response * egp.egp(freqs, sources[source_name], matrix)

        elif source_name == 'extra_DWD':
            psd += response * extra_foreground(freqs, sources[source_name])
            if injected:
                true_psd.append(response * extra_foreground(freqs, sources[source_name]))

        elif source_name == 'fraction':
            psd += response * Omega_fraction(freqs, sources[source_name])
            if injected:
                true_psd.append(response * Omega_fraction(freqs, sources[source_name]))

        elif source_name == 'galactic_DWD':
            psd += galactic_foreground(freqs, sources[source_name], injected=injected)
            if injected:
                true_psd.append(galactic_foreground(freqs, sources[source_name], injected=injected))

        elif source_name == 'galactic_DWD_time':
            t1 = kwargs.get('t1')
            t2 = kwargs.get('t2')
            psd += galactic_foreground_time(freqs, sources[source_name], t1=t1, t2=t2, tdi=tdi, injected=injected)
            if injected:
                true_psd.append(galactic_foreground_time(freqs, sources[source_name], t1=t1, t2=t2, tdi=tdi, injected=injected))

        elif source_name == 'galactic_prototype':
            t1 = kwargs.get('t1')
            t2 = kwargs.get('t2')
            psd += galactic_prototype(freqs, sources[source_name], t1=t1, t2=t2, tdi=tdi, injected=injected)
            if injected:
                true_psd.append(galactic_prototype(freqs, sources[source_name], t1=t1, t2=t2, tdi=tdi, injected=injected))

        elif source_name == 'instr_noise':
            psd += noise(freqs, sources[source_name])
            if injected:
                true_psd.append(noise(freqs, sources[source_name]))

    # Return the total PSD and optionally the true PSDs for each source
    if injected:
        return psd, true_psd
    else:
        return psd


##################################################################################
# DATA GENERATION AND PROCESSING
##################################################################################
def reconstruct_symmetric_matrices(upper_list):
    num_elements = len(upper_list)
    # Solve quadratic: ndim*(ndim+1)//2 = num_elements
    ndim = int((-1 + (1 + 8 * num_elements)**0.5) // 2)

    assert ndim * (ndim + 1) // 2 == num_elements, "Invalid list length for upper triangle"

    nfreqs = upper_list[0].shape[0]
    full_matrices = np.zeros((nfreqs, ndim, ndim))

    # Upper triangle indices
    triu_indices = np.triu_indices(ndim)

    for f in range(nfreqs):
        # Fill upper triangle
        full_matrices[f][triu_indices] = [arr[f] for arr in upper_list]
        # Reflect to lower triangle
        full_matrices[f] = full_matrices[f] + np.triu(full_matrices[f], k=1).T

    return full_matrices


def GP_freq(freqs, dt, psd, seed=42, time=False):
    """
    Generates a stationary Gaussian process using the inverse FFT method.

    Args:
        freqs (array): Frequency array.
        dt (float): Time step.
        psd (array): Power spectral density.
        seed (int): Random seed.
        time (bool or str): If True, returns time-domain signal. If 'both', returns both time and frequency domain.

    Returns:
        tuple: Frequency and Fourier coefficients, or time and signal, or both.
    """
    np.random.seed(seed)
    amp_r = np.random.normal(loc=np.zeros_like(freqs), scale=np.sqrt(psd * (len(freqs) / dt)))
    amp_i = np.random.normal(loc=np.zeros_like(freqs), scale=np.sqrt(psd * (len(freqs) / dt)))
    fourier_coeffs = (amp_r + 1j * amp_i) / np.sqrt(2)
    fourier_coeffs[0] = 0

    if time == True:
        x = np.fft.irfft(fourier_coeffs, n=len(freqs) * 2)
        t = np.arange(len(freqs) * 2) * dt
        return t, x
    elif time == 'both':
        x = np.fft.irfft(fourier_coeffs, n=len(freqs) * 2)
        t = np.arange(len(freqs) * 2) * dt
        return freqs, fourier_coeffs, t, x
    else:
        return freqs, fourier_coeffs
    

def MGP_freq(freqs, dt, psd, seed=42):
    """
    Generates a stationary process using a Multivariate Gaussian process in frequency domain.

    Args:
        freqs (array): Frequency array (positive frequencies).
        dt (float): Time step.
        psd (array): 2D array (matrix) of power spectral density values, shape (len(freqs), N, N),
                     where N is the number of channels/dimensions.
        seed (int): Random seed.

    Returns:
        tuple: (freqs, Fourier coefficients) where the Fourier coefficients is a complex array of shape (len(freqs), N).
    """
    np.random.seed(seed)
    n_freqs, n_dim, _ = psd.shape

    # Scale PSD to get covariance 
    covs = n_freqs * dt * psd# shape: (n_freqs, n_dim, n_dim)

    # Cholesky decomposition: shape (n_freqs, n_dim, n_dim)
    L = np.linalg.cholesky(covs)

    # Standard normal real and imaginary parts: shape (n_freqs, n_dim)
    z_real = np.random.randn(n_freqs, n_dim)
    z_imag = np.random.randn(n_freqs, n_dim)

    # Batched matrix multiplication: L @ z.T → shape (n_freqs, n_dim)
    real_part = np.einsum('fij,fj->fi', L, z_real)
    imag_part = np.einsum('fij,fj->fi', L, z_imag)

    coeffs = (real_part + 1j * imag_part) / np.sqrt(2)

    return freqs, coeffs


def average_chunks(freqs, data, response, chunk_size):
    """
    Averages data in chunks.

    Args:
        freqs (array): Frequency array.
        data (array): Data array.
        response (array): Response array.
        chunk_size (int): Size of each chunk.

    Returns:
        tuple: Averaged frequency, data, and response arrays.
    """
    data_chunks = np.array_split(data, len(data) // chunk_size)
    response_chunks = np.array_split(response, len(data) // chunk_size)
    freq_chunks = np.array_split(freqs, len(data) // chunk_size)

    d = [np.mean(chunk) for chunk in data_chunks]
    r = [np.mean(chunk) for chunk in response_chunks]
    f = [np.mean(chunk) for chunk in freq_chunks]

    return np.array(f), np.array(d), np.array(r)


def average_log_chunks(freqs, data, response, num_bins=50):
    """
    Averages data in logarithmic bins.

    Args:
        freqs (array): Frequency array.
        data (array): Data array.
        response (array): Response array.
        num_bins (int): Number of bins.

    Returns:
        tuple: Averaged frequency, data, response, and count arrays.
    """
    freqs = np.asarray(freqs)
    data = np.asarray(data)
    response = np.asarray(response)

    log_min = np.log10(np.min(freqs[freqs > 0]))
    log_max = np.log10(np.max(freqs))
    log_bins = np.logspace(log_min, log_max, num_bins + 1)

    f_avg, d_avg, r_avg, count = [], [], [], []

    for i in range(num_bins):
        mask = (freqs >= log_bins[i]) & (freqs < log_bins[i + 1])
        if np.any(mask):
            f_avg.append(0.5 * (freqs[mask][0] + freqs[mask][-1]))
            d_avg.append(np.mean(data[mask]))
            r_avg.append(np.mean(response[mask]))
            count.append(np.sum(mask))

    return np.array(f_avg), np.array(d_avg), np.array(r_avg), np.array(count)
            