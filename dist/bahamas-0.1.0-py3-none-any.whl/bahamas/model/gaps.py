import numpy as np

def generate_gaps(T_obs, scheduled_gap=7*3600, scheduled_period=14*86400, unscheduled_gap=3*86400, exp_scale=10*86400, merge_threshold=1*86400, duty_cycle=0.75):
    """
    Generate scheduled and unscheduled gaps for observing time.
    Args:
        T_obs (float): Total observation time in seconds.
        scheduled_gap (float): Duration of scheduled gaps in seconds.
        scheduled_period (float): Period of scheduled gaps in seconds.
        unscheduled_gap (float): Duration of unscheduled gaps in seconds.
        exp_scale (float): Scale for the exponential distribution for unscheduled gaps.
        merge_threshold (float): Threshold for merging gaps in seconds.
        duty_cycle (float): Desired duty cycle for observing time.
    Returns:
        tuple: Two arrays containing the start and end times of the gaps.
    """
    # Generate scheduled gaps
    scheduled_gaps = [(i, i + scheduled_gap) for i in np.arange(0, T_obs, scheduled_period)]
    merged_gaps =[]

    if unscheduled_gap > 0:
        # Generate unscheduled gaps
        unscheduled_gaps = []
        t = np.random.exponential(exp_scale)
        while t + unscheduled_gap < T_obs:
            unscheduled_gaps.append((t, t + unscheduled_gap))
            t += np.random.exponential(exp_scale) + unscheduled_gap

        # Combine gaps
        all_gaps = sorted(scheduled_gaps + unscheduled_gaps)

        # Merge overlapping or close gaps
        
        for start, end in all_gaps:
            if merged_gaps and start - merged_gaps[-1][1] < merge_threshold:
                merged_gaps[-1] = (merged_gaps[-1][0], max(merged_gaps[-1][1], end))
            else:
                merged_gaps.append((start, end))

        # Adjust for duty cycle (rescale gaps to ensure 75% observing time)
        total_gap_time = sum(end - start for start, end in merged_gaps)
        required_gap_time = (1 - duty_cycle) * T_obs

        if total_gap_time > required_gap_time:
            excess_time = total_gap_time - required_gap_time
            while excess_time > 0 and merged_gaps:
                start, end = merged_gaps.pop()
                excess_time -= end - start

    else:
        for start, end in scheduled_gaps:
            merged_gaps.append((start, end))

    merged_gaps = np.asarray(merged_gaps)
    return merged_gaps.T[0], merged_gaps.T[1]
