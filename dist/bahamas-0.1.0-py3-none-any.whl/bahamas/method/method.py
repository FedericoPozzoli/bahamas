"""
This module provides methods for prior sampling, likelihood computation, and transformations 
between hypercube and hypertriangle spaces. It is used for Bayesian inference in signal processing.

Functions:
    hypertriangulate(x, bounds): Transforms a vector from the hypercube to the hypertriangle.
    hypercubify(y, bounds): Inverse of hypertriangulate, maps from the hypertriangle to the hypercube.
    prior_sample(sources): Samples parameters from prior distributions for multiple sources.
    whittle_lik(data, freqs, response, count, sources, ...): Computes the Whittle likelihood.
    gamma_lik(data, freqs, response, count, sources, ...): Computes the Gamma likelihood.
    temperature_scaled_log_likelihood(log_like_fn, beta): Scales a log-likelihood by a temperature factor.

Dependencies:
    - JAX
    - NumPyro
    - psd_function (custom module)
"""
from bahamas.model import psd_function as psd


import numpy as np
import jax
import jax.numpy as jnp
import jax.scipy as jsc
import numpyro
import numpyro.distributions as dist
from jax import lax, random, vmap
from jax.scipy.special import logsumexp

# Hypercube to Hypertriangle Transformations
####################################################################################################

def hypertriangulate(x, bounds=(0, 1)):
    """
    Transform a vector of numbers from the hypercube to the hypertriangle.

    Parameters:
    - x (array-like): Input vector in the hypercube.
    - bounds (tuple): Bounds of the hypercube (default: (0, 1)).

    Returns:
    - array-like: Transformed vector in the hypertriangle.
    """
    x = jnp.array(x)
    unit_x = (x - bounds[0]) / (bounds[1] - bounds[0])
    
    n = unit_x.shape[-1]
    index = jnp.arange(n)
    inner_term = jnp.power(1 - unit_x, 1 / (n - index))
    unit_y = 1 - jnp.cumprod(inner_term, axis=-1)
    
    y = bounds[0] + unit_y * (bounds[1] - bounds[0])
    return y

def hypercubify(y, bounds=(0, 1)):
    """
    Inverse of hypertriangulate. Maps from the hypertriangle to the hypercube.

    Parameters:
    - y (array-like): Input vector in the hypertriangle.
    - bounds (tuple): Bounds of the hypertriangle (default: (0, 1)).

    Returns:
    - array-like: Transformed vector in the hypercube.
    """
    y = jnp.array(y)
    unit_y = (y - bounds[0]) / (bounds[1] - bounds[0])
    
    n = unit_y.shape[-1]
    index = jnp.arange(n)
    unit_y_shifted = jnp.roll(unit_y, 1, axis=-1).at[..., 0].set(0)
    unit_x = 1 - jnp.power((1 - unit_y) / (1 - unit_y_shifted), n - index)
    
    x = bounds[0] + unit_x * (bounds[1] - bounds[0])
    return x

####################################################################################################

# Prior Sampling
def prior_sample(sources):
    """
    Sample parameters from prior distributions for multiple sources.

    Parameters:
    - sources (dict): Dictionary of sources and their parameter configurations.

    Returns:
    - dict: Dictionary of sampled parameters for each source.
    """
    samples = {}
    for source_name, param_list in sources.items():
        if source_name == 'egp':
            source_samples = {}
            for param in param_list:
                if param['name'] == 'knots':
                    samp = {
                        f"delta_{i}": numpyro.sample(f"{source_name}_delta_{i}", dist.Uniform(*param["bounds"]))
                        for i in range(param['num'])
                    }
                else:
                    samp = {
                        param["name"]: numpyro.sample(f"{source_name}_{param['name']}", dist.Uniform(*param["bounds"]))
                        if param["bounds"] else param["injected"]
                    }
                source_samples.update(samp)

        elif source_name == 'galactic_prototype':
            source_samples = {}
            for param in param_list:
                if param['name'] == 'w':
                    K = param["component"]
                    weights = numpyro.sample(f"{source_name}_w", dist.Dirichlet(jnp.ones(K)))
                    samp = {param['name']: jnp.array(weights)}
                    source_samples.update(samp)
                elif param['name'] in ['sX', 'sY']:
                    var = []
                    for i, range in enumerate(param['bounds']):
                        variance = numpyro.sample(f"{source_name}_{param['name']}_{i}", dist.Uniform(*range))
                        var.append(variance)
                    samp = {param['name']: jnp.array(var)}
                    source_samples.update(samp)
                else:
                    samp = {
                        param["name"]: numpyro.sample(f"{source_name}_{param['name']}", dist.Uniform(*param["bounds"]))
                        if param["bounds"] else param["injected"]
                    }
                    source_samples.update(samp)
        else:
            source_samples = {
                param["name"]: numpyro.sample(f"{source_name}_{param['name']}", dist.Uniform(*param["bounds"]))
                if param["bounds"] else param["injected"]
                for param in param_list
            }
        samples[source_name] = source_samples
    return samples

# Likelihood Functions
def whittle_lik(data, freqs, response, sources, count, dt, t1, t2, dof, matrix_egp):
    """
    Compute the Whittle likelihood.

    Parameters:
    - data (list): Observed data segments.
    - freqs (list): Frequency grids for each segment.
    - response (list): Response functions for each segment.
    - count (list): Counts for each segment.
    - sources (dict): Source parameters.
    - dt (float): Time step.
    - t1, t2 (list): Start and end times for each segment.
    - dof (list): Degrees of freedom for each segment.
    - matrix_egp (array): Matrix for EGP modeling.

    Returns:
    - None: Adds the log-likelihood factor to the NumPyro model.
    """
    sample = prior_sample(sources)
    log_likelihood = 0
    for j, segment in enumerate(data):
        for i, tdi in enumerate(segment):
            f, n = jnp.array(freqs[j]), dof[j]
            psd_model = psd.model_psd(freqs=f, response=response[j][i], sources=sample, t1=t1[j], t2=t2[j], matrix_egp=matrix_egp, tdi=i)
            psd_model = (n / dt) * psd_model
            log_likelihood += -0.5 * jnp.sum((jnp.abs(tdi) ** 2) / psd_model) - 0.5 * len(f) * jnp.log(2 * jnp.pi) - 0.5 * jnp.sum(jnp.log(psd_model))
    numpyro.factor("log_likelihood", log_likelihood)

def gamma_lik(data, freqs, response, sources, count, dt, t1, t2, dof, matrix_egp):
    """
    Compute the Gamma likelihood.

    Parameters:
    - data (list): Observed data segments.
    - freqs (list): Frequency grids for each segment.
    - response (list): Response functions for each segment.
    - count (list): Counts for each segment.
    - sources (dict): Source parameters.
    - dt (float): Time step.
    - t1, t2 (list): Start and end times for each segment.
    - dof (list): Degrees of freedom for each segment.
    - matrix_egp (array): Matrix for EGP modeling.

    Returns:
    - None: Adds the log-likelihood factor to the NumPyro model.
    """
    sample = prior_sample(sources)
    log_likelihood = 0
    for j, segment in enumerate(data):
        for i, tdi in enumerate(segment):
            f = jnp.array(freqs[j])
            psd_model = psd.model_psd(freqs=f, response=response[j][i], sources=sample, t1=t1[j], t2=t2[j], matrix_egp=matrix_egp, tdi=i) / count[j]
            log_likelihood += -jnp.sum(jsc.special.gammaln(count[j])) - jnp.sum(count[j] * jnp.log(psd_model)) + jnp.sum((count[j] - 1) * jnp.log(tdi)) - jnp.sum(tdi / psd_model)
    numpyro.factor("log_likelihood", log_likelihood)

# Temperature Scaling for Log-Likelihood
def temperature_scaled_log_likelihood(log_like_fn, beta):
    """
    Scale a log-likelihood function by a temperature factor.

    Parameters:
    - log_like_fn (callable): Log-likelihood function.
    - beta (float): Temperature scaling factor.

    Returns:
    - callable: Scaled log-likelihood function.
    """
    def scaled_likelihood(data, freqs, response, sources, count, dt, t1, t2, dof, matrix_egp):
        with numpyro.handlers.scale(scale=beta): 
            return log_like_fn(data, freqs, response, sources, count, dt, t1, t2, dof, matrix_egp=matrix_egp)
    return scaled_likelihood
