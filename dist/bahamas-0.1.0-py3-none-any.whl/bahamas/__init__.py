"""
BAHAMAS - Bayesian Hamiltonian Monte Carlo Analysis for Stochastic gravitational wave signal
"""

__version__ = "0.1.0"

