"""Run inference on selected config files."""

import subprocess
import multiprocessing
import os
import sys
import argparse
import itertools
import logging
from ruamel.yaml import YAML
# Initialize YAML reader/writer
yaml = YAML()
yaml.preserve_quotes = True

# Set up logging
logger = logging.getLogger('TheFirstYear')
logger.setLevel(logging.DEBUG)

# Add a console handler with formatting
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)  # Change to DEBUG to see debug messages
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

def run_inference(files):
    """Run inference on a single config file."""
    config_file, pe_file = files

    command = [
        "python", "inference.py", 
        "--config", config_file, 
        "--sources", pe_file
    ]
    logger.info(f"Starting inference with {config_file}")  # Use logger
    logger.info(f"{command}")
    subprocess.run(command)
    logger.info(f"Finished inference with {config_file}")  # Use logger

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run inference on selected config files.")
    parser.add_argument("--folder", type=str, help="Folder of PEs")
    parser.add_argument("--month", type=int, nargs='+', help="List of Months")
    parser.add_argument("--lik", type=str, help="Likelihood type", choices=["Gamma", "Whittle"])
    parser.add_argument("--method", type=str, help="Inference method", choices=["cyclo", "stat"])
    parser.add_argument("--sampler", type=str, help="Type of Sampler", choices=["hmc", "nested"])
    parser.add_argument("--ntemp", type=int, help="Number of temperatures (required if sampler is 'hmc')")
    parser.add_argument("--ncores", type=int, help="Number of cores available (default to 4)", default=4)
    parser.add_argument("--temp", type=int, nargs = '+', help="List of temperatures (required if sampler is 'hmc')")
    parser.add_argument("--steps", type=int, nargs='+', help="List of chain steps for each temperature")


    args = parser.parse_args()
    main_folder = args.folder
    month = args.month
    lik = args.lik
    method = args.method
    sampler = args.sampler
    cores = args.ncores
    
    #ntemp or temp must be provided with hmc
    if sampler == "hmc":
        if args.ntemp is None and args.temp is None:
            logger.error("Error: --ntemp or --temp must be specified when using the 'hmc' sampler.")
            sys.exit(1)

        #check that if ntemp is provided, temp is not
        if args.ntemp is not None and args.temp is not None:
            logger.error("Error: --ntemp and --temp cannot be used together.")
            sys.exit(1)

        if args.temp is not None:
            #check that steps is not None
            if args.steps is None:
                logger.error("Error: --steps must be specified when using the 'temp' sampler.")
                sys.exit(1)
    
            #check steps has same length as temp
            if len(args.steps) != len(args.temp):
                logger.error("Error: --steps must have the same length as --ntemp when using the 'hmc' sampler.")
                sys.exit(1)

            temp = args.temp
            steps = args.steps

        elif args.ntemp is not None:
            #check that steps is None
            if args.steps is not None:
                logger.error("Error: --steps cannot be used with --ntemp.")
                sys.exit(1)
                
            ntemp = args.ntemp

    # Build the list of config files
    config_files = []
    if sampler == "hmc":
        if args.ntemp is not None:
            for i, j in itertools.product(month, range(1, ntemp + 1)):
                #complete path + file
                config_files.append(f"{main_folder}/month_{i}/{sampler}/{lik}/{method}/temp_{j}/config_month{i}_{lik}_{method}_temp{j}.yaml")
        elif args.temp is not None:
            for i, j in itertools.product(month, temp):
                #complete path + file
                file = f"{main_folder}/month_{i}/{sampler}/{lik}/{method}/temp_{j}/config_month{i}_{lik}_{method}_temp{j}.yaml"
                
                #check that file exists
                if not os.path.exists(file):
                    logger.error(f"Error: Config file {file} does not exist.")
                    sys.exit(1)

                #open the file and change the steps
                with open(file, 'r') as f:
                    config = yaml.load(f)
                f.close()
                #change the steps 
                config['inference']['samples'] = steps[temp.index(j)]
                #write the file
                with open(file, 'w') as f:
                    yaml.dump(config, f)
                f.close()
                #append the file to the list
                #complete path + file   
                config_files.append(f"{main_folder}/month_{i}/{sampler}/{lik}/{method}/temp_{j}/config_month{i}_{lik}_{method}_temp{j}.yaml")
                
    elif sampler == "nested":
        for i in month:
            #complete path + file
            config_files.append(f"{main_folder}/month_{i}/{sampler}/{lik}/{method}/config_month{i}_{lik}_{method}.yaml")
    else:
        logger.error("Error: Sampler must be either 'hmc' or 'nested'.")
    

    
    logger.info(f"Found Config files to process: {len(config_files)}")
    #check that config files exist
    for c in config_files:
        if not os.path.exists(c):
            logger.error(f"Error: Config file {c} does not exist.")
            sys.exit(1)

    # Build the list of PE files
    pe_files = []
    
    for i in month:
        if sampler == "hmc":
            if args.ntemp is not None:
                for j in range(1, ntemp + 1):
                    pe_files.append(f"{main_folder}/month_{i}/{sampler}/{lik}/{method}/pe_month{i}_{method}.yaml")

            elif args.temp is not None:
                for j in temp:
                    pe_files.append(f"{main_folder}/month_{i}/{sampler}/{lik}/{method}/pe_month{i}_{method}.yaml")

        elif sampler == "nested":
            pe_files.append(f"{main_folder}/month_{i}/{sampler}/{lik}/{method}/pe_month{i}_{method}.yaml")
            
        else:
            logger.error("Error: Sampler must be either 'hmc' or 'nested'.")

    logger.info(f"Found PE files to process: {len(pe_files)}")
    #check that PE files exist
    for p in pe_files:
        if not os.path.exists(p):
            logger.error(f"Error: PE file {p} does not exist.")
            sys.exit(1)

    num_processes = min(len(config_files), cores)

    # Tell the user what you are going to run
    logger.info(f"Will run the following using {num_processes}.")
    for c,p in zip(config_files, pe_files):
        logger.info(f"\n python inference.py --config {c} --sources {p}")
    # Ensure the number of processes does not exceed the number of config files
    with multiprocessing.Pool(processes=num_processes) as pool:
        pool.map(run_inference, zip(config_files, pe_files))
  

    logger.info("Processing completed.")
