"""
This module performs Bayesian inference using various sampling methods provided by NumPyro and Nessai.

Classes:
    Method: Handles different methods of inference.
    BayesianInference: Manages the entire inference process, including loading configurations, running inference, and saving results.

Functions:
    get_last_part(path): Extracts the last part of a file path.

Usage:
    Run the script with the required command-line arguments for configuration and sources files.
"""
from bahamas.method import method
from bahamas.method import method_nessai
from bahamas.method import setting_inference

import numpy as np
import jax
import numpyro
from numpyro.infer import BarkerMH, MCMC, NUTS, DiscreteHMCGibbs
from numpyro.infer import SVI, autoguide, Trace_ELBO
import yaml
import argparse
import matplotlib.pyplot as plt
import corner
import os
from nessai.flowsampler import FlowSampler
import logging

# Enable 64-bit precision in NumPyro
numpyro.enable_x64()

# Set up logging
logger = logging.getLogger('BAHAMAS_Inference')
logger.setLevel(logging.DEBUG)

# Add a console handler with formatting
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)  # Change to DEBUG to see debug messages
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)


def get_last_part(path: str) -> str:
    """
    Extract the last part of a file path.

    Parameters:
    - path (str): The file path.

    Returns:
    - str: The last part of the file path.
    """
    return os.path.basename(path)

def get_first_part(path: str) -> str:
    """
    Extract the first part of a file path.

    Parameters:
    - path (str): The file path.

    Returns:
    - str: The first part of the file path.
    """
    return os.path.dirname(path)


class Method:
    """
    Class to handle the different methods of inference.
    """

    def __init__(self, config, log_like, **kwargs):
        """
        Initialize the Method class.

        Parameters:
        - config (dict): Configuration dictionary.
        - log_like (callable): Log-likelihood function.
        - kwargs (dict): Additional arguments for the inference method.
        """
        self.config = config
        self.log_like = log_like
        self.sampler = self.config['inference']['sampler']
        self.kwargs = kwargs

    def setup(self):
        """
        Set up the inference method based on the sampler specified in the configuration.
        """
        if self.sampler == 'NUTS':

            kernel = NUTS(self.log_like, adapt_mass_matrix=self.config['inference']['adapt_matrix'])
            self.method = MCMC(kernel, **self._get_mcmc_params())

        elif self.sampler == 'DiscreteHMCGibbs':
            kernel = DiscreteHMCGibbs(NUTS(self.log_like, adapt_mass_matrix=self.config['inference']['adapt_matrix']))
            self.method = MCMC(kernel, **self._get_mcmc_params())

        elif self.sampler == 'BarkerMH':
            kernel = BarkerMH(self.log_like, adapt_mass_matrix=self.config['inference']['adapt_matrix'])
            self.method = MCMC(kernel, **self._get_mcmc_params())

        elif self.sampler == 'SVI':
            optimizer = numpyro.optim.Adam(step_size=0.0005)
            self.guide = autoguide.AutoBNAFNormal(self.log_like)
            loss = Trace_ELBO() if self.config['inference']['loss'] == 'ELBO' else None
            self.method = SVI(self.log_like, guide=self.guide, optim=optimizer, loss=loss)

        elif self.sampler == 'nested':

            sampler_opts = self.config['inference']

            # To get checkpointing to work
            if 'flow_config' not in sampler_opts:
                sampler_opts['flow_config'] = None
            if 'checkpointing' not in sampler_opts:
                sampler_opts['checkpointing'] = True
            if 'checkpoint_on_training' not in sampler_opts:
                sampler_opts['checkpoint_on_training'] = True
            
            if 'max_threads' in sampler_opts:
                nthreads = sampler_opts['max_threads']

            model = method_nessai.nessai_model(self.log_like, **self.kwargs)
            name = get_first_part(self.config['inference']['file_post'])
            self.method = FlowSampler(model, resume=False, output=name, **sampler_opts,)


    def _get_mcmc_params(self):
        """
        Helper function to get MCMC parameters from the configuration.

        Returns:
        - dict: MCMC parameters.
        """
        return {
            'num_warmup': self.config['inference']['warmup'],
            'num_samples': self.config['inference']['samples'],
            'num_chains': self.config['inference']['chains'],
            'chain_method': self.config['inference']['chain_method'],
            'jit_model_args': False
        }
        
    def run(self):
        """
        Run the inference method and return the posterior samples.

        Returns:
        - np.ndarray: Posterior samples.
        """
        if self.sampler == 'SVI':
            svi_result = self.method.run(jax.random.PRNGKey(100), num_steps=self.config['inference']['steps'], **self.kwargs)
            params = svi_result.params
            self.posterior = self.guide.sample_posterior(jax.random.PRNGKey(100), params, sample_shape=(self.config['inference']['samples'],))
            self.result = np.column_stack([self.posterior[key] for key in self.posterior])
            self.plot_corner()
            self.plot_autocorrelation()
            self.get_likelihood()
            return self.result

        elif self.sampler in ['BarkerMH', 'NUTS', 'DiscreteHMCGibbs']:
            self.method.run(jax.random.PRNGKey(100), **self.kwargs)
            self.posterior = self.method.get_samples()
            self.result = np.column_stack([self.posterior[key] for key in self.posterior])
            self.plot_corner()
            self.plot_autocorrelation()

            if 'temperature' in self.config['inference']:
                self.get_likelihood()
                #add to posterior "log_likelihood"
                self.posterior['log_likelihood'] = self.loglike
                #add to posterior "log_likelihood"
                self.posterior['temperature'] = self.config['inference']['temperature']
                self.result = self.posterior

            return self.result
   

        elif self.sampler == 'nested':
            self.method.run()
            self.posterior = self.method.posterior_samples
            self.result = np.column_stack([self.posterior[key] for key in self.posterior.dtype.names])
            return self.result

    def get_likelihood(self):
        """
        Compute and print the marginalized log-likelihood.
        """
        loglike = numpyro.infer.util.log_likelihood(model=self.log_like, posterior_samples=self.posterior, **self.kwargs)
        self.loglike = loglike.get('log_likelihood')
        
        

    def plot_corner(self):
        """
        Create and save a corner plot of the posterior samples.
        """
        plt.figure()
        corner.corner(self.result, quiet = True)
        name_ = get_last_part(self.config['inference']['file'])
        name_folder = get_first_part(self.config['inference']['file_post'])
        plt.savefig(f'{name_folder}/corner_{name_}.png')

    def plot_autocorrelation(self):
        """
        Create and save an autocorrelation plot of the posterior samples.
        """
        corr = numpyro.diagnostics.autocorrelation(self.result, axis=0)

        if 'temperature' in self.config['inference']:
            self.result['autocorr'] = corr
            
        plt.figure()
        for i in corr.T:
            plt.plot(i, alpha=0.3)
        plt.semilogx()
        plt.ylabel('Autocorrelation')
        name_ = get_last_part(self.config['inference']['file'])
        name_folder = get_first_part(self.config['inference']['file_post'])
        plt.savefig(f'{name_folder}/auto_{name_}.png')


class BayesianInference:
    """
    Class to manage the entire Bayesian inference process.
    """

    def __init__(self, config_file, sources_file):
        """
        Initialize the BayesianInference class.

        Parameters:
        - config_file (str): Path to the configuration file.
        - sources_file (str): Path to the sources file.
        """
        self.config_file = config_file
        self.sources_file = sources_file
        self.load_config_files()

    def load_config_files(self):
        """
        Load the configuration and sources files.
        """
        with open(self.sources_file, "r") as file:
            self.sources = yaml.safe_load(file)['sources']
        with open(self.config_file, "r") as file:
            self.config = yaml.safe_load(file)

        self.log_like, self.data, self.freqs, self.response, self.count, self.dt, self.t1, self.t2, self.dof, self.matrix_egp = set.set_inference(
            config=self.config, sources=self.sources)

    def run_inference(self):
        """
        Run the inference method.

        Returns:
        - np.ndarray: Posterior samples.
        """
        kwargs = {
            'data': self.data, 'freqs': self.freqs, 'response': self.response, 'count': self.count,
            'sources': self.sources, 'dt': self.dt, 't1': self.t1, 't2': self.t2, 'dof': self.dof, 'matrix_egp': self.matrix_egp
        }
        method = Method(self.config, self.log_like, **kwargs)
        method.setup()
        return method.run()

    def save_results(self):
        """
        Save the posterior samples to a file.
        """
        np.savez(self.config['inference']["file_post"], posterior=self.result)

    def run(self):
        """
        Run the entire inference process.
        """
        self.result = self.run_inference()
        self.save_results()


if __name__ == '__main__':
    # Argument parsing for command-line interface
    parser = argparse.ArgumentParser(description='Bayesian Inference for LISA Data')
    parser.add_argument('--config', type=str, required=True, help='YAML config file')
    parser.add_argument('--sources', type=str, required=True, help='YAML sources file')
    args = parser.parse_args()

    logger.info(f"Running inference with config: {args.config} and sources: {args.sources}")
    logger.info("JAX devices available: %s", jax.devices())
    logger.info("Running inference...")
   
    inference = BayesianInference(args.config, args.sources)
    inference.run()

    logger.info("Inference completed successfully.")
    logger.info("Results saved to: %s", inference.config['inference']["file_post"])