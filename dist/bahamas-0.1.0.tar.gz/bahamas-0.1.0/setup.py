from setuptools import setup, find_packages

setup(
    name='bahamas',
    version='0.1.0',
    description='BAyesian HAmiltonian Montecarlo Analysis for Stochastic gravitational wave signal',
    author='Federico Pozzoli',
    author_email='fpozzoli@uninsubria.it',
    packages=find_packages(include=['bahamas', 'bahamas.*']),
    install_requires=[
        # add your required dependencies here, e.g.:
        'numpy',
        'scipy',
        'torch',
        'matplotlib',
        'nessai',
        # etc.
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
)

