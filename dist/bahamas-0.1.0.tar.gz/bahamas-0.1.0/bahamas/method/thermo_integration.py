import os
import numpy as np
import jax.numpy as jnp
from numpyro import handlers
import numpyro.infer as infer
import jax
import yaml


def compute_evidence_from_posteriors(folder, min_T = 0.01, max_T = 1., num_temperatures=20):
    """
    Compute the evidence using thermodynamic integration from posterior samples stored in a folder.

    Args:
        folder (str): Path to the folder containing posterior samples for each temperature.
        num_temperatures (int): Number of temperatures to integrate over.

    Returns:
        float: Estimated log marginal likelihood (evidence).
    """
    # Temperatures range from 1 (full likelihood) to a small value (approaching the prior)
    beta = jnp.linspace(min_T, max_T, num_temperatures)

    # Store log-likelihood values for integration
    log_marginal_likelihood = []

    for i, b in enumerate(beta):
        # Construct the folder name for the current temperature
        temp_folder = os.path.join(folder, f"temp_{i+1}")
        if not os.path.exists(temp_folder):
            raise FileNotFoundError(f"Temperature folder not found: {temp_folder}")

        # Look for the file starting with "result" in the folder
        result_file = None
        for file_name in os.listdir(temp_folder):
            if file_name.startswith("result") and file_name.endswith(".npz"):
                result_file = os.path.join(temp_folder, file_name)
                break

        if not result_file:
            raise FileNotFoundError(f"No result file found in folder: {temp_folder}")
        # Load the result file
        post = np.load(result_file, allow_pickle=True)['posterior'][()]
        if post is None:
            raise ValueError(f"Posterior samples not found in file: {result_file}")

        log_likelihoods = post['log_likelihood']

        # Compute the average log-likelihood for this temperature
        avg_log_likelihood = jnp.mean(log_likelihoods)
        log_marginal_likelihood.append(avg_log_likelihood)

        print(f"Temperature {b:.2f} - Log Marginal Likelihood: {avg_log_likelihood:.4f}")

    # Convert to JAX array
    log_marginal_likelihood = jnp.array(log_marginal_likelihood)

    # Compute numerical integration using the trapezoidal rule
    temperature_deltas = jnp.diff(beta)
    marginal_likelihood = jnp.sum(
        0.5 * (log_marginal_likelihood[:-1] + log_marginal_likelihood[1:]) * temperature_deltas
    )

    print(f"Estimated Log Marginal Likelihood (Evidence): {marginal_likelihood:.4f}")
    return marginal_likelihood


if __name__ == '__main__':
    # Argument parsing for command-line interface
    import argparse

    parser = argparse.ArgumentParser(description='Compute evidence using thermodynamic integration.')
    parser.add_argument('--folder', type=str, required=True, help='Folder containing posterior samples.')
    parser.add_argument('--num_temperatures', type=int, default=20, help='Number of temperatures to integrate over.')
    args = parser.parse_args()

    # Compute evidence
    evidence = compute_evidence_from_posteriors(folder=args.folder, num_temperatures=args.num_temperatures)
    print(f"Final Evidence: {evidence:.4f}")