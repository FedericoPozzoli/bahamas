# BAHAMAS

**BAyesian HAmiltonian Montecarlo Analysis for Stochastic gravitational wave signal**

A Python package for full inference of stochastic gravitational wave background signals using advanced HMC and Bayesian methods.

## Features

- HMC and nested sampling for SGWB
- Supports LISA response modeling
- EGP modeling and thermodynamic integration
- CLI support via `bahamas-run`

## Installation

```bash
pip install -e .

